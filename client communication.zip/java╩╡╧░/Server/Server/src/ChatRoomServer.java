import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

/**
 * 多人聊天室服务器
 */
public class ChatRoomServer extends JFrame {

    private JPanel contentPane;
    private ServerSocket serverSocket;
    private Set<PrintWriter> writers = new HashSet<>();
    private JTextArea textArea;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                ChatRoomServer frame = new ChatRoomServer();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public ChatRoomServer() {
        setTitle("210601225彭琛聊天室服务器");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 300);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(new BorderLayout(0, 0));

        JLabel lblNewLabel = new JLabel("聊天记录");
        lblNewLabel.setFont(new Font("Lucida Grande", Font.BOLD, 16));
        lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
        contentPane.add(lblNewLabel, BorderLayout.NORTH);

        JScrollPane scrollPane = new JScrollPane();
        contentPane.add(scrollPane, BorderLayout.CENTER);

        textArea = new JTextArea();
        textArea.setEditable(false);
        scrollPane.setViewportView(textArea);

        try {
            serverSocket = new ServerSocket(8888);
            addMessage("聊天室服务器已启动，等待客户端连接...");
            while (true) {
                Socket socket = serverSocket.accept();
                new ClientHandler(socket).start();
            }
        } catch (IOException e) {
            addMessage("服务器启动失败：" + e.getMessage());
        } finally {
            try {
                serverSocket.close();
            } catch (IOException e) {
                addMessage("I/O错误：" + e);
            }
            catch(NullPointerException e){

            }
        }
    }

    private void addMessage(String message) {
        textArea.append(message + "\n");
    }

    private class ClientHandler extends Thread {
        private Socket socket;
        private PrintWriter writer;

        public ClientHandler(Socket socket) {
            this.socket = socket;
        }

          @Override
    public void run() {
        try {
            Scanner scanner = new Scanner(socket.getInputStream());
            writer = new PrintWriter(socket.getOutputStream(), true);
            writers.add(writer);

            String nickname = scanner.nextLine();
            addMessage(nickname + " 加入了聊天室");

            // 发送欢迎信息
            writer.println("欢迎"+ nickname +"加入聊天室!" );

            while (true) {
                String message = scanner.nextLine();
                if (message.startsWith("/quit")) {
                    return; // 客户端退出
                }
                broadcast( "：" + message);
            }
        } catch (IOException e) {
            addMessage("I/O错误：" + e);
                }
            }
        

        private void broadcast(String message) {
            for (PrintWriter writer : writers) {
                writer.println(message);
            }
        }
    }

}
