import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

/**
 * ���������ҿͻ���
 */
public class ChatRoomClient extends JFrame {

    private JPanel contentPane;
    private JTextField textField;
    private JTextArea textArea;
    private JButton btnSend;
    private JTextArea iparea;
    private JTextField ipfield;
    private JTextArea port;
    private  JTextField portfiled;
    private JTextArea name;
    private JTextField namefield;
    private JButton connect;
    private JButton exit;
    private JPanel group;
    private Socket socket;
    private Scanner input;
    private PrintWriter output;
    private String nickname;
   // private ArrayList<String> connectedUsernames;
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                ChatRoomClient frame = new ChatRoomClient();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
    public String getNickname() {
        return nickname;
    }

    public ChatRoomClient() {
        setTitle("�����ҿͻ���");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1200, 2000);
        group=new JPanel();
        group.setLayout(new FlowLayout());
        iparea=new JTextArea("IP");
        port=new JTextArea("�˿�");
        name=new JTextArea("�ǳ�");
        iparea.setEditable(false);
        port.setEditable(false);
        name.setEditable(false);
        ipfield=new JTextField();
        portfiled=new JTextField();
        namefield=new JTextField();
        connect=new JButton("����������");
        connect.setPreferredSize(new Dimension(200,20));
        connect.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ipfield.setEnabled(false);

                portfiled.setEnabled(false);
                namefield.setEnabled(false);
                connect.setEnabled(false);


                String host=ipfield.getText();
                if (host == null || host.isEmpty()) {
                System.exit(0);
            }
                int port= Integer.parseInt(portfiled.getText());
                if(port!=8888){
                    System.exit(0);
                }
                try {
                    socket = new Socket(host, port);
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    input = new Scanner(socket.getInputStream());
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    output = new PrintWriter(socket.getOutputStream(), true);
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
                nickname=namefield.getText();
                if (nickname == null || nickname.isEmpty()) {
                System.exit(0);
            }
            setTitle("210601225��������ҿͻ��� - " + nickname);

            // ��ȡ���������ص���Ϣ
            new Thread(new Runnable() {
                @Override
                public void run() {
                    while (true) {
                        String message = input.nextLine();
                        LocalDateTime currentDateTime = LocalDateTime.now();

// ����ʱ���ʽ
                        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");

// ��ʽ��ʱ��
                        String formattedDateTime = currentDateTime.format(formatter);
                        textArea.append("["+formattedDateTime+"] "+message + "\n");
                    }
                }
            }).start();
//
            output.println("��ӭ"+nickname+"����������"); // �����ǳƵ������

            }
        });
        exit=new JButton("�˳�������");
        exit.setPreferredSize(new Dimension(200,20));
        exit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                output.println(nickname+"�뿪��������");
                System.exit(0);
            }
        });
        group.add(iparea);
        group.add(ipfield);
        ipfield.setPreferredSize(new Dimension(100,20));
        portfiled.setPreferredSize(new Dimension(100,20));
        namefield.setPreferredSize(new Dimension(100,20));
        group.add(port);
        group.add(portfiled);
        group.add(name);
        group.add(namefield);
        group.add(connect);
        group.add(exit);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(new BorderLayout());

        JLabel lblNewLabel = new JLabel("�����¼");
        lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
        contentPane.add(lblNewLabel, BorderLayout.NORTH);
        contentPane.add(group,BorderLayout.NORTH);
        JScrollPane scrollPane = new JScrollPane();
        contentPane.add(scrollPane, BorderLayout.CENTER);

        textArea = new JTextArea();
        textArea.setEditable(false);

        scrollPane.setViewportView(textArea);

        JPanel panel = new JPanel();
        contentPane.add(panel, BorderLayout.SOUTH);
        panel.setLayout(new BorderLayout(0, 0));

        textField = new JTextField();
        panel.add(textField, BorderLayout.CENTER);
        textField.setPreferredSize(new Dimension(1200,150));
        textField.setColumns(10);

        btnSend = new JButton("����");
        btnSend.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String message = textField.getText().trim();
                if (message.isEmpty()) {
                    return;
                }
                output.println(nickname + "��" + message);
                textField.setText("");
            }
        });
        panel.add(btnSend, BorderLayout.EAST);


    }

}
