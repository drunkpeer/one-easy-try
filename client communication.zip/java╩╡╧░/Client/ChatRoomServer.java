import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;

/**
 *          ?     
 */
public class ChatRoomServer {
    static int index=0;
    //  ��       ?                   ?    ��?  ??  ?
    private static Set<PrintWriter> writers = new HashSet<>();
    private String[] nicknames=new String[10];

    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = new ServerSocket(8888);
        System.out.println("     ?              ?  ?       ...");
        try {
            while (true) {
                Socket socket = serverSocket.accept();
                //     ?   ��  ??   ?       
                new ClientHandler(socket).start();
            }
        } finally {
            serverSocket.close();
        }
    }

    /**
     *  ?  ?    ? 
     */

    private static class ClientHandler extends Thread {
        private Socket socket;
        private PrintWriter writer;
        private Scanner scanner;

        //  ��     ?  ? 
        private static Set<String> nicknameSet = new HashSet<>();

        public ClientHandler(Socket socket) {
            this.socket = socket;
        }

        @Override
        public void run() {
            try {
                scanner = new Scanner(socket.getInputStream());
                writer = new PrintWriter(socket.getOutputStream(), true);
                //    ??  ?        ?  writers       
                writers.add(writer);
           output = new PrintWriter(client.getOutputStream(), true);
                //      ? 
                String nickname = scanner.nextLine();
                if (nickname.isEmpty()) {
                    output.println("Nickname can't be empty!");
                    return;
                } else if (nicknameSet.contains(nickname)) {
                    output.println("Nickname already exists!");
                    return;
                }
                nicknameSet.add(nickname); //    ?   ?  nicknameSet   

                //   ? ?  ?  ?   ?   ?     ��?   
                while (true) {

                    String message = scanner.nextLine();
                    if (message.startsWith("/quit")) {
                        return; //  ?    ? 
                    }
                    broadcast(message); //  ?  ?     ��?   
                }
            } catch (IOException e) {
                System.out.println("I/O    " + e);

            }
            catch (NoSuchElementException e){
//            System.out.println("I/O    " + e);
            }
            finally {
                if (writer != null) {
                    writers.remove(writer);
                }
                try {
                    socket.close();
                } catch (IOException e) {
                    System.out.println("Socket ??   " + e);
                }
            }
        }

        /**
         *  ?  ?     ��?   
         * @param message   ?    
         */
        private void broadcast(String message) {
            for (PrintWriter writer : writers) {
                writer.println(message);
            }
        }
    }

//    private static class Task implements Runnable {
//        private Socket client;
//        private String[] nicknames;
//        private Scanner input;
//        private PrintWriter output;
//
//        public Task(Socket client, String[] nicknames) throws IOException {
//            this.client = client;
//            this.nicknames = nicknames;
//            input = new Scanner(client.getInputStream());
//            output = new PrintWriter(client.getOutputStream(), true);
//        }
//
//        @Override
//        public void run() {
//            //...
//            String nickname = input.nextLine();
//            if (nickname.isEmpty()) {
//                output.println("Nickname can't be empty!");
//                return;
//            } else if (Arrays.asList(nicknames).contains(nickname)) {
//                output.println("Nickname already exists!");
//                return;
//            }
//            //...
//
//            nicknames[index++] = nickname; // after successful connection, store the nickname in the array
//        }
//    }
}
